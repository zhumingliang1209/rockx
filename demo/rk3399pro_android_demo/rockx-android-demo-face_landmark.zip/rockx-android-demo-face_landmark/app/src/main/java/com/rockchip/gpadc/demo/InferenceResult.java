package com.rockchip.gpadc.demo;

import android.content.res.AssetManager;
import android.graphics.RectF;

import java.io.IOException;
import java.util.ArrayList;

import static java.lang.System.arraycopy;

public class InferenceResult {

    OutputBuffer mOutputBuffer;
    ArrayList<Face> faces = null;
    private boolean mIsVaild = false;   //是否需要重新计算
    public byte[] img = null;

    public void init(AssetManager assetManager) throws IOException {
        mOutputBuffer = new OutputBuffer();
    }

    public void reset() {
        if (faces != null) {
            faces.clear();
            mIsVaild = true;
        }
    }

    public synchronized void setResult(ArrayList<Face> faces) {
        this.faces = faces;
    }

    public synchronized ArrayList<Face> getResult() {
        if(this.faces != null)
            return (ArrayList<Face>)this.faces.clone();
        else
            return null;
    }

    public static class OutputBuffer {
        public float[] mLocations;
        public float[] mClasses;
    }

}
