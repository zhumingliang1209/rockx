package com.rockchip.gpadc.demo.rga;

public class RGA {
    static {
        System.loadLibrary("rknn4j");
    }

    public static int colorConvert(byte[] src, int srcWidth, int srcHeight, int srcFmt,
                            byte[] dst, int dstWidth, int dstHeight, int dstFmt, int flip) {

        return color_convert(src, srcWidth, srcHeight, srcFmt,
                dst, dstWidth, dstHeight, dstFmt, flip);
    }

    private static native int color_convert(byte[] src, int srcWidth, int srcHeight, int srcFmt,
                                     byte[] dst, int dstWidth, int dstHeight, int dstFmt, int flip);
}
