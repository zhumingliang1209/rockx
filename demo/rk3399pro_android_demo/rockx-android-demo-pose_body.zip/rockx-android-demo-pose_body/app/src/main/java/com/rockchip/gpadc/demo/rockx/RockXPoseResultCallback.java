package com.rockchip.gpadc.demo.rockx;

public interface RockXPoseResultCallback {
    void onResult(KeyPoints[] keyPointsArray);
}
