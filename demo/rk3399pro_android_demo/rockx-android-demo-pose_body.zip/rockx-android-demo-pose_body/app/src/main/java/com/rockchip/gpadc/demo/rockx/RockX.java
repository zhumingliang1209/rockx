package com.rockchip.gpadc.demo.rockx;

import android.util.Log;

public class RockX {

    public static final int ROCKX_MODULE_FACE_DETECTION = 1;
    public static final int ROCKX_MODULE_FACE_LANDMARK_68 = 2;
    public static final int ROCKX_MODULE_FACE_RECOGNIZE = 3;
    public static final int ROCKX_MODULE_FACE_ANALYZE = 4;
    public static final int ROCKX_MODULE_OBJECT_DETECTION = 5;
    public static final int ROCKX_MODULE_POSE_BODY = 6;
    public static final int ROCKX_MODULE_POSE_FINGER = 7;
    public static final int ROCKX_MODULE_FACE_LANDMARK_5 = 8;
    public static final int ROCKX_MODULE_HEAD_DETECTION = 9;
    public static final int ROCKX_MODULE_CARPLATE_DETECTION = 10;
    public static final int ROCKX_MODULE_CARPLATE_ALIGN = 11;
    public static final int ROCKX_MODULE_CARPLATE_RECOG = 12;
    public static final int ROCKX_MODULE_OBJECT_TRACK = 13;

    public static final int ROCKX_PIXEL_FORMAT_GRAY8 = 0;
    public static final int ROCKX_PIXEL_FORMAT_RGB888 = 1;
    public static final int ROCKX_PIXEL_FORMAT_BGR888 = 2;

    private long mRockXPoseBodyModule;

    public RockX() {
    }

    public void create() {
        mRockXPoseBodyModule = native_create_rockx_module(ROCKX_MODULE_POSE_BODY);
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        native_destroy_rockx_module(mRockXPoseBodyModule);
    }

    public void setPoseResultCallback(RockXPoseResultCallback callback) {
        native_set_callback(callback);
    }

    public int getBodyKeyPoints(byte[] inData, int inWidth, int inHeight, int inPixelFmt) {
        int ret = native_pose_body(mRockXPoseBodyModule, inData, inWidth, inHeight, inPixelFmt);
        if (ret < 0) {
            Log.e("RockX", "native_pose_body error " + ret);
            return -1;
        }
        return 0;
    }

    private native long native_create_rockx_module(int module);
    private native void native_destroy_rockx_module(long handle);
    private native void native_set_callback(RockXPoseResultCallback callback);
    private native int native_pose_body(long handle, byte[] inData, int inWidth, int inHeight, int inPixelFmt);

    static {
        System.loadLibrary("rknn4j");
    }
}
