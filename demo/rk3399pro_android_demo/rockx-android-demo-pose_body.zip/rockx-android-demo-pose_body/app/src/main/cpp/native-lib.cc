
#include <jni.h>

#include "rga/RKRGAProxy.h"

RKRGAProxy *rga = new RKRGAProxy();

int colorConvert(void *src, int srcWidth, int srcHeight, int srcFmt,
                 void *dst, int dstWidth, int dstHeight, int dstFmt, int flip){
    return rga->convert(src, srcWidth, srcHeight, srcFmt,
                        dst, dstWidth, dstHeight, dstFmt, flip);
}

extern "C"
JNIEXPORT jint JNICALL Java_com_rockchip_gpadc_demo_rga_RGA_color_1convert(JNIEnv *env, jobject instance,
                                                                 jbyteArray src_, jint srcWidth,
                                                                 jint srcHeight, jint srcFmt,
                                                                 jbyteArray dst_, jint dstWidth,
                                                                 jint dstHeight, jint dstFmt,
                                                                 jint flip) {
    jboolean copy = JNI_FALSE;
    jbyte *src = env->GetByteArrayElements(src_, &copy);
    jbyte *dst = env->GetByteArrayElements(dst_, &copy);

    colorConvert(src, srcWidth, srcHeight, srcFmt,
                 (void *)dst, dstWidth, dstHeight, dstFmt, flip);

    env->ReleaseByteArrayElements(src_, src, 0);
    env->ReleaseByteArrayElements(dst_, dst, 0);
    return 0;
}