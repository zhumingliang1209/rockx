#include "rockx.h"
#include "log.h"
#include "jni.h"
#include <unistd.h>
#include <string.h>
#include <cstdlib>

static JavaVM *g_vm = nullptr;

static jobject g_result_callback_obj;

static jobject gClassLoader;

static jmethodID gFindClassMethod;


/*************************************************************************
                        comman function
**************************************************************************/
static char* jstringToChar(JNIEnv* env, jstring jstr) {
    char* rtn = NULL;
    jclass clsstring = env->FindClass("java/lang/String");
    jstring strencode = env->NewStringUTF("utf-8");
    jmethodID mid = env->GetMethodID(clsstring, "getBytes", "(Ljava/lang/String;)[B");
    jbyteArray barr = (jbyteArray) env->CallObjectMethod(jstr, mid, strencode);
    jsize alen = env->GetArrayLength(barr);
    jbyte* ba = env->GetByteArrayElements(barr, JNI_FALSE);

    if (alen > 0) {
        rtn = new char[alen + 1];
        memcpy(rtn, ba, alen);
        rtn[alen] = 0;
    }
    env->ReleaseByteArrayElements(barr, ba, 0);
    return rtn;
}

void get_global_class_loader(JNIEnv *env) {
    jclass randomClass = env->FindClass("com/rockchip/gpadc/demo/rockx/RockX");
    jclass classClass = env->GetObjectClass(randomClass);
    jclass classLoaderClass = env->FindClass("java/lang/ClassLoader");
    jmethodID getClassLoaderMethod = env->GetMethodID(classClass, "getClassLoader",
                                                      "()Ljava/lang/ClassLoader;");
    jobject localClassLoader = env->CallObjectMethod(randomClass, getClassLoaderMethod);

    gClassLoader = env->NewGlobalRef(localClassLoader);
    gFindClassMethod = env->GetMethodID(classLoaderClass, "findClass",
                                        "(Ljava/lang/String;)Ljava/lang/Class;");
}

jclass findClass(JNIEnv *env, const char* name) {
    jclass result = nullptr;
    if (env)
    {
        result = env->FindClass(name);
        jthrowable exception = env->ExceptionOccurred();
        if (exception)
        {
            env->ExceptionClear();
            return static_cast<jclass>(env->CallObjectMethod(gClassLoader, gFindClassMethod, env->NewStringUTF(name)));
        }
    }
    return result;
}


/*************************************************************************
                        rockx jni api
**************************************************************************/
extern "C"
JNIEXPORT jlong JNICALL Java_com_rockchip_gpadc_demo_rockx_RockX_native_1create_1rockx_1module
  (JNIEnv *env, jobject obj, jint module) {
    rockx_ret_t ret;

    rockx_handle_t handle;

    ret = rockx_create(&handle, (rockx_module_t)module, nullptr, 0);
    if (ret != ROCKX_RET_SUCCESS) {
        LOGI("init rockx module %d error %d\n", module, ret);
        return ret;
    }

	return (jlong)handle;
}

extern "C"
JNIEXPORT void JNICALL Java_com_rockchip_gpadc_demo_rockx_RockX_native_1destroy_1rockx_1module
		(JNIEnv *env, jobject obj, jlong handle) {
	rockx_destroy((rockx_handle_t)handle);
}

/*************************************************************************
                        rockx openpose jni api
**************************************************************************/
jobject keypoints_c2j(JNIEnv *env, rockx_keypoints_t *keypoints) {
    jclass cls_KeyPoints = findClass(env, "com/rockchip/gpadc/demo/rockx/KeyPoints");
    jmethodID KeyPoints_construct = env->GetMethodID(cls_KeyPoints, "<init>", "(I)V");
    jmethodID KeyPoints_set = env->GetMethodID(cls_KeyPoints, "setPoint", "(III)V");

    jvalue * args = (jvalue*)malloc(1*sizeof(jvalue));
    args[0].i = keypoints->count;
    jobject keypoints_j = env->NewObjectA(cls_KeyPoints, KeyPoints_construct, args);
    free(args);

    for (int i = 0; i < keypoints->count; i++) {
        LOGI("i = %d", i);
        LOGI("args1 %d %d %d", i, keypoints->points[i].x, keypoints->points[i].y);
        env->CallVoidMethod(keypoints_j, KeyPoints_set, i, keypoints->points[i].x, keypoints->points[i].y);
        LOGI("i = %d end", i);
    }

    return keypoints_j;
}

int keypoints_array_c2j(JNIEnv *env, rockx_keypoints_array_t *keypoints_array, jobject keypointsList) {
    jclass cls_ArrayList = findClass(env, "java.util.ArrayList");
    jmethodID ArrayList_add = env->GetMethodID(cls_ArrayList, "add", "(Ljava/lang/Object;)Z");

    for (int i = 0; i < keypoints_array->count; i++) {
        jobject result = keypoints_c2j(env, &(keypoints_array->keypoints[i]));
        env->CallBooleanMethod(keypointsList, ArrayList_add, result);
    }

    return 0;
}

jobjectArray keypoints_array_c2j(JNIEnv *env, rockx_keypoints_array_t *keypoints_array) {
    jclass cls_KeyPoints = findClass(env, "com/rockchip/gpadc/demo/rockx/KeyPoints");
    jobjectArray keyPointsArray = env->NewObjectArray(keypoints_array->count, cls_KeyPoints, NULL);

    for (int i = 0; i < keypoints_array->count; i++) {
        jobject result = keypoints_c2j(env, &(keypoints_array->keypoints[i]));
        env->SetObjectArrayElement(keyPointsArray, i, result);
    }

    return keyPointsArray;
}

void callback_f(void *result, size_t result_size) {
    LOGI("on callback");

    jboolean need_detach = JNI_FALSE;

    rockx_keypoints_array_t *body_array = (rockx_keypoints_array_t*)result;

    JNIEnv *env;
    int getEnvStat = g_vm->GetEnv( (void **) &env, JNI_VERSION_1_6);
    if (getEnvStat == JNI_EDETACHED) {
        if (g_vm->AttachCurrentThread(&env, NULL) != 0) {
            LOGE("AttachCurrentThread Error")
            return;
        }
        need_detach = JNI_TRUE;
    }

    jclass cls_RockXPoseResultCallback = env->GetObjectClass(g_result_callback_obj);
    if (cls_RockXPoseResultCallback == 0) {
        LOGE("unable to find class RockXPoseResultCallback");
        g_vm->DetachCurrentThread();
        return;
    }

    jmethodID RockXPoseResultCallback_onResult = env->GetMethodID(cls_RockXPoseResultCallback,
            "onResult", "([Lcom/rockchip/gpadc/demo/rockx/KeyPoints;)V");

    jobjectArray resultArray = keypoints_array_c2j(env, body_array);
    env->CallVoidMethod(g_result_callback_obj, RockXPoseResultCallback_onResult, resultArray);

    if(need_detach) {
        g_vm->DetachCurrentThread();
    }
}

extern "C"
JNIEXPORT void Java_com_rockchip_gpadc_demo_rockx_RockX_native_1set_1callback
    (JNIEnv *env, jobject obj, jobject resultCallback) {
    env->GetJavaVM(&g_vm);
    g_result_callback_obj = env->NewGlobalRef(resultCallback);

    get_global_class_loader(env);
}

extern "C"
JNIEXPORT jint JNICALL Java_com_rockchip_gpadc_demo_rockx_RockX_native_1pose_1body
    (JNIEnv *env, jobject obj, jlong handle, jbyteArray inData, jint inWidth, jint inHeight, jint inPixelFmt) {

    jboolean inputCopy = JNI_FALSE;
    jbyte* in_data = env->GetByteArrayElements(inData, &inputCopy);

    // init rockx_image_t
    rockx_image_t input_image;
    input_image.width = inWidth;
    input_image.height = inHeight;
    input_image.data = (unsigned char *)in_data;
    input_image.pixel_format = (rockx_pixel_format)inPixelFmt;

    // body pose
    LOGI("before rockx_pose_body");
    rockx_ret_t ret = rockx_pose_body((rockx_handle_t)handle, &input_image, nullptr, callback_f);
    if (ret != ROCKX_RET_SUCCESS) {
        LOGI("rockx_pose_body error %d\n", ret);
        return -1;
    }
    LOGI("after rockx_pose_body");


    env->ReleaseByteArrayElements(inData, in_data, JNI_ABORT);

    return 0;
}