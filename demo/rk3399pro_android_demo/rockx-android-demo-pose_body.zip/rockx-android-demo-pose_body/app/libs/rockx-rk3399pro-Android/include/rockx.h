/****************************************************************************
*
*    Copyright (c) 2017 - 2019 by Rockchip Corp.  All rights reserved.
*
*    The material in this file is confidential and contains trade secrets
*    of Rockchip Corporation. This is proprietary information owned by
*    Rockchip Corporation. No part of this work may be disclosed,
*    reproduced, copied, transmitted, or used in any way for any purpose,
*    without the express written permission of Rockchip Corporation.
*
*****************************************************************************/

#ifndef _ROCKX_H
#define _ROCKX_H

#include <stddef.h>

#include "rockx_type.h"
#include "modules/face.h"
#include "modules/pose.h"
#include "modules/object_detection.h"
#include "modules/carplate.h"
#include "modules/object_track.h"
#include "utils/rockx_tensor_util.h"
#include "utils/rockx_image_util.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief RockX Modules Define
 *
 * @details This is using for create a RockX module(See @ref rockx_create)
 */
typedef enum {
    ROCKX_MODULE_FACE_DETECTION      = 1,    ///< Face Detection
    ROCKX_MODULE_FACE_LANDMARK_68    = 2,    ///< Face Landmark (68 KeyPoints)
    ROCKX_MODULE_FACE_RECOGNIZE      = 3,    ///< Face Recognition
    ROCKX_MODULE_FACE_ANALYZE        = 4,    ///< Face Attribute(Gender and Age) Analyze
    ROCKX_MODULE_OBJECT_DETECTION    = 5,    ///< Object Detection(91 Classes)
    ROCKX_MODULE_POSE_BODY           = 6,    ///< Body Pose(14 KeyPoints)
    ROCKX_MODULE_POSE_FINGER_21      = 7,    ///< Finger Landmark(21 KeyPoint)
    ROCKX_MODULE_FACE_LANDMARK_5     = 8,    ///< Face Landmark(5 KeyPoints)
    ROCKX_MODULE_HEAD_DETECTION      = 9,    ///< Head Detection
    ROCKX_MODULE_CARPLATE_DETECTION  = 10,   ///< Car Plate Detection
    ROCKX_MODULE_CARPLATE_ALIGN      = 11,   ///< Car Plate Correct Alignment
    ROCKX_MODULE_CARPLATE_RECOG      = 12,   ///< Car Plate Recognition
    ROCKX_MODULE_OBJECT_TRACK        = 13,    ///< Object Track
    ROCKX_MODULE_POSE_FINGER_3       = 14    ///< Finger Landmark(3 KeyPoint)
} rockx_module_t;

/// Create A Rockx Module
/// \param handle [out] The handle for created module
/// \param m [in] Enum of RockX module(@ref rockx_module_t)
/// \param config [in] Config for Rockx Module
/// \param config_size [in] Size of config
/// \return @ref rockx_ret_t
rockx_ret_t rockx_create(rockx_handle_t *handle, rockx_module_t m, void *config, size_t config_size);

/// Destroy A Rockx Module
/// \param handle [in] The handle of a created module (created by @ref rockx_create)
/// \return @ref rockx_ret_t
rockx_ret_t rockx_destroy(rockx_handle_t handle);

#ifdef __cplusplus
} //extern "C"
#endif

#endif // _ROCKX_H
