# 使用说明
 - 可以使用android studio编译该工程
 - 安装后需要在设置打开camera权限

 
