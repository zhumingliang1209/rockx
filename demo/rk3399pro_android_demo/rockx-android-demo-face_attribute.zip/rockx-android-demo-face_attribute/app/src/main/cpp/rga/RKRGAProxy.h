//
// Created by randall on 19-2-14.
//

#ifndef RKSSDDEMO_RKRGAPROXY_H
#define RKSSDDEMO_RKRGAPROXY_H

#include <errno.h>
#include "drmrga.h"
#include "RgaApi.h"
#include "graphics-base.h"


class RKRGAProxy {
private:
    void * mContext;
    bool mSupportRga;

private:
    int RkRgaInit();

public:

    RKRGAProxy();
    ~RKRGAProxy();

    int convert(void *src, int srcWidth, int srcHeight, int srcFmt,
             void *dst, int dstWidth, int dstHeight, int dstFmt, int flip);

};


#endif //RKSSDDEMO_RKRGAPROXY_H
