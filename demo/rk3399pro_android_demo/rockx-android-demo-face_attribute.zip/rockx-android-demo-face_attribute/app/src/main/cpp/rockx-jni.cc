#include "rockx.h"
#include "log.h"
#include "jni.h"
#include <unistd.h>
#include <string.h>
#include <cstdlib>

/*************************************************************************
                        comman function
**************************************************************************/
static char* jstringToChar(JNIEnv* env, jstring jstr) {
    char* rtn = NULL;
    jclass clsstring = env->FindClass("java/lang/String");
    jstring strencode = env->NewStringUTF("utf-8");
    jmethodID mid = env->GetMethodID(clsstring, "getBytes", "(Ljava/lang/String;)[B");
    jbyteArray barr = (jbyteArray) env->CallObjectMethod(jstr, mid, strencode);
    jsize alen = env->GetArrayLength(barr);
    jbyte* ba = env->GetByteArrayElements(barr, JNI_FALSE);

    if (alen > 0) {
        rtn = new char[alen + 1];
        memcpy(rtn, ba, alen);
        rtn[alen] = 0;
    }
    env->ReleaseByteArrayElements(barr, ba, 0);
    env->DeleteLocalRef(clsstring);
    env->DeleteLocalRef(strencode);
    return rtn;
}

jobject face_c2j(JNIEnv *env, rockx_object_t *face, int inWidth, int inHeight) {
    jclass cls_Face = env->FindClass("com/rockchip/gpadc/demo/Face");
    jmethodID Face_construct = env->GetMethodID(cls_Face, "<init>", "(FFFFFF)V");
    //jmethodID Face_setLandmark = env->GetMethodID(cls_Face, "setLandmark", "([F)V");
    //jmethodID Face_setAntiSpoofScore = env->GetMethodID(cls_Face, "setAntiSpoofScore", "([F)V");

    jvalue * args = (jvalue*)malloc(6*sizeof(jvalue));
    args[0].f = (float)face->box.left / inWidth;
    args[1].f = (float)face->box.top / inHeight;
    args[2].f = (float)face->box.right / inWidth;
    args[3].f = (float)face->box.bottom / inHeight;
    args[4].f = face->score;
    args[5].f = face->id;
    LOGI("(%f %f %f %f) %f \t%f", args[0].f, args[1].f, args[2].f, args[3].f, args[4].f, args[5].f)
    jobject facej = env->NewObjectA(cls_Face, Face_construct, args);
    if (args != nullptr) {
        free(args);
    }
    env->DeleteLocalRef(cls_Face);
    return facej;
}


int face_array_c2j(JNIEnv *env, rockx_object_array_t *face_array, jobject faceList, int inWidth, int inHeight) {
    jclass cls_ArrayList = env->GetObjectClass(faceList);
    jmethodID ArrayList_add = env->GetMethodID(cls_ArrayList, "add", "(Ljava/lang/Object;)Z");

    for (int i = 0; i < face_array->count; i++) {
        jobject face = face_c2j(env, &(face_array->object[i]), inWidth, inHeight);
        env->CallBooleanMethod(faceList, ArrayList_add, face);
        env->DeleteLocalRef(face);
    }
    env->DeleteLocalRef(cls_ArrayList);
    return 0;
}

/*
int face_j2c(JNIEnv *env, jobject face, face_array_t *face_array) {
    jclass cls_Face = env->GetObjectClass(face);
    jclass cls_Rect = env->FindClass("android/graphics/Rect");

    jmethodID Face_getBox = env->GetMethodID(cls_Face, "getBox", "(V)Landroid/graphics/Rect;");

    jobject box = env->CallObjectMethod(cls_face, Face_getBox);


    return 0;
}
*/

/*************************************************************************
                        rockx jni api
**************************************************************************/
extern "C"
JNIEXPORT jlong JNICALL Java_com_rockchip_gpadc_demo_rockx_RockX_native_1create_1rockx_1module
  (JNIEnv *env, jobject obj, jstring modelPath, jint module)
{
    rockx_ret_t ret;

    rockx_handle_t handle;

	char *model_path = jstringToChar(env, modelPath);

    ret = rockx_create(&handle, (rockx_module_t)module, nullptr, 0);
    if (ret != ROCKX_RET_SUCCESS) {
        LOGI("init rockx module %d error %d\n", module, ret);
        return ret;
    }

	return (jlong)handle;
}

extern "C"
JNIEXPORT void JNICALL Java_com_rockchip_gpadc_demo_rockx_RockX_native_1destroy_1rockx_1module
		(JNIEnv *env, jobject obj, jlong handle) {
	rockx_destroy((rockx_handle_t)handle);
}

/*************************************************************************
                        rockx face jni api
**************************************************************************/
extern "C"
JNIEXPORT jint JNICALL Java_com_rockchip_gpadc_demo_rockx_RockX_native_1face_1detect
        (JNIEnv *env, jobject obj, jlong det_handle, jlong track_handle, jbyteArray inData, jint inWidth, jint inHeight,
                jint max_track_time, jint inPixelFmt,
            jobject faceList) {

  	jboolean inputCopy = JNI_FALSE;
  	jbyte* in_data = env->GetByteArrayElements(inData, &inputCopy);

    // initial rockx_image_t variable
    rockx_image_t input_image;
    input_image.width = inWidth;
    input_image.height = inHeight;
    input_image.data = (unsigned char *)in_data;
    input_image.pixel_format = (rockx_pixel_format)inPixelFmt;

    // create rockx_face_array_t for store result
    rockx_object_array_t face_array;
    memset(&face_array, 0, sizeof(rockx_object_array_t));

    // detect face
    rockx_ret_t ret = rockx_face_detect((rockx_handle_t)det_handle, &input_image, &face_array, nullptr);
    if (ret != ROCKX_RET_SUCCESS) {
        printf("rockx_face_detect error %d\n", ret);
        return -1;
    }

    ret = rockx_object_track((rockx_handle_t)track_handle, inWidth, inHeight, max_track_time,
                                         &face_array, &face_array);
    if (ret != ROCKX_RET_SUCCESS) {
        printf("rockx_face_detect error %d\n", ret);
        return -1;
    }

    face_array_c2j(env, &face_array, faceList, inWidth, inHeight);

	env->ReleaseByteArrayElements(inData, in_data, JNI_ABORT);

	return 0;
}


extern "C"
JNIEXPORT jint JNICALL Java_com_rockchip_gpadc_demo_rockx_RockX_native_1get_1align_1face
        (JNIEnv *env, jobject obj, jlong handle, jbyteArray inData, jint inWidth, jint inHeight, jint inPixelFmt,
            jint boxLeft, jint boxTop, jint boxRight, jint boxBottom,
            jintArray outLandmark, jbyteArray outAlignedFaceData) {

  	jboolean inputCopy = JNI_FALSE;
  	jbyte* in_data = env->GetByteArrayElements(inData, &inputCopy);
 	jboolean outputCopy = JNI_FALSE;
  	jint* out_landmark = env->GetIntArrayElements(outLandmark, &outputCopy);
	jbyte* out_aligned_face_data = env->GetByteArrayElements(outAlignedFaceData, &outputCopy);

    // initial rockx_image_t variable
    rockx_image_t input_image;
    input_image.width = inWidth;
    input_image.height = inHeight;
    input_image.data = (unsigned char *)in_data;
    input_image.pixel_format = (rockx_pixel_format)inPixelFmt;

    rockx_rect_t face_box;
    face_box.left = boxLeft;
    face_box.top = boxTop;
    face_box.right = boxRight;
    face_box.bottom = boxBottom;

    LOGI("align face %d %d %d %d", boxLeft, boxTop, boxRight, boxBottom);

    // create rockx_face_array_t for store result
    rockx_face_landmark_t face_landmark5;
    rockx_image_t out_aligned_image;
    memset(&face_landmark5, 0, sizeof(rockx_face_landmark_t));
    memset(&out_aligned_image, 0, sizeof(rockx_image_t));

    // detect face
    rockx_ret_t ret = rockx_face_align((rockx_handle_t)handle, &input_image, &face_box, nullptr, &out_aligned_image);
    if (ret != ROCKX_RET_SUCCESS) {
        printf("rockx_get_align_face error %d\n", ret);
        return -1;
    }

    memcpy(out_aligned_face_data, out_aligned_image.data, 112*112*3);

    rockx_image_release(&out_aligned_image);

    for (int i = 0; i < 5; i++) {
        out_landmark[i] = face_landmark5.landmarks[i].x;
        out_landmark[i+5] = face_landmark5.landmarks[i].y;
    }
    //memcpy(out_aligned_face_data, out_aligned_image.data, out_aligned_image.width*out_aligned_image.height*3);

	env->ReleaseByteArrayElements(inData, in_data, JNI_ABORT);
	env->ReleaseIntArrayElements(outLandmark, out_landmark, 0);
	env->ReleaseByteArrayElements(outAlignedFaceData, out_aligned_face_data, 0);

	return 0;
}


extern "C"
JNIEXPORT jint JNICALL Java_com_rockchip_gpadc_demo_rockx_RockX_native_1face_1attribute
        (JNIEnv *env, jobject obj, jlong handle, jbyteArray inAlignedFaceData, jintArray outResult) {

    jboolean inputCopy = JNI_FALSE;
    jbyte* const in_aligned_face_data = env->GetByteArrayElements(inAlignedFaceData, &inputCopy);
    jint* const out_ga_result = env->GetIntArrayElements(outResult, &inputCopy);

    // initial rockx_image_t variable
    rockx_image_t input_image;
    input_image.width = 112;
    input_image.height = 112;
    input_image.data = (unsigned char *)in_aligned_face_data;
    input_image.pixel_format = ROCKX_PIXEL_FORMAT_RGB888;

    // create rockx_face_array_t for store result
    rockx_face_attribute_t gender_age;
    memset(&gender_age, 0, sizeof(rockx_face_attribute_t));

    // ga
    rockx_ret_t ret = rockx_face_attribute((rockx_handle_t)handle, &input_image, &gender_age);
    if (ret != ROCKX_RET_SUCCESS) {
        printf("rockx_ga error %d\n", ret);
        return -1;
    }

    LOGI("ga gender=%d age=%d", gender_age.gender, gender_age.age);

    out_ga_result[0] = gender_age.gender;
    out_ga_result[1] = gender_age.age;

    env->ReleaseByteArrayElements(inAlignedFaceData, in_aligned_face_data, JNI_ABORT);
    env->ReleaseIntArrayElements(outResult, out_ga_result, 0);

    return 0;
}