package com.rockchip.gpadc.demo.rockx;

import com.rockchip.gpadc.demo.Face;
import com.rockchip.gpadc.demo.GA;

import java.util.ArrayList;

public class RockX {

    private static final int ROCKX_MODULE_FACE_DETECTION = 1;
    private static final int ROCKX_MODULE_FACE_LANDMARK = 2;
    private static final int ROCKX_MODULE_FACE_RECOGITION = 3;
    private static final int ROCKX_MODULE_FACE_ANALYZE = 4;
    private static final int ROCKX_MODULE_OBJECT_DETECTION = 5;
    private static final int ROCKX_MODULE_POSE_BODY = 6;
    private static final int ROCKX_MODULE_POSE_FINGER = 7;
    private static final int ROCKX_MODULE_FACE_5LANDMARKS = 8;
    private static final int ROCKX_MODULE_HEAD_DETECTION = 9;
    private static final int ROCKX_MODULE_CARPLATE_DETECTION = 10;
    private static final int ROCKX_MODULE_CARPLATE_ALIGN = 11;
    private static final int ROCKX_MODULE_CARPLATE_RECOG = 12;
    private static final int ROCKX_MODULE_OBJECT_TRACK = 13;
    private static final int ROCKX_MODULE_FACE_ANTISPOOF = 14;

    public static final int ROCKX_PIXEL_FORMAT_GRAY8 = 0;
    public static final int ROCKX_PIXEL_FORMAT_RGB888 = 1;
    public static final int ROCKX_PIXEL_FORMAT_BGR888 = 2;

    private String mModelPath;

    private long mRockXFaceDetectionModule;
    private long mRockXFaceLandmark5Module;
    private long mRockXFaceAnalyzeModule;
    private long mRockXObjectTrackModule;

    public RockX(String model_path) {
        mModelPath = model_path;
    }

    public void create() {
        mRockXFaceDetectionModule = native_create_rockx_module(mModelPath, ROCKX_MODULE_FACE_DETECTION);
        mRockXFaceLandmark5Module = native_create_rockx_module(mModelPath, ROCKX_MODULE_FACE_5LANDMARKS);
        mRockXFaceAnalyzeModule = native_create_rockx_module(mModelPath, ROCKX_MODULE_FACE_ANALYZE);
        mRockXObjectTrackModule = native_create_rockx_module(mModelPath, ROCKX_MODULE_OBJECT_TRACK);
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        native_destroy_rockx_module(mRockXFaceDetectionModule);
        native_destroy_rockx_module(mRockXFaceLandmark5Module);
        native_destroy_rockx_module(mRockXFaceAnalyzeModule);
        native_destroy_rockx_module(mRockXObjectTrackModule);
    }

    public ArrayList<Face> detectFace(byte[] inData, int inWidth, int inHeight, int max_track_time, int inPixelFmt) {
        ArrayList<Face> faceList = new ArrayList<>();
        native_face_detect(mRockXFaceDetectionModule, mRockXObjectTrackModule, inData, inWidth, inHeight, max_track_time, inPixelFmt, faceList);
        return faceList;
    }

    public int alignFace(byte[] inData, int inWidth, int inHeight, int inPixelFmt, Face face) {
        int landmark[] = new int[10];
        byte alignedFaceData[] = new byte[112*112*3];

        int box_left = (int)(face.getLocation().left*inWidth);
        int box_top = (int)(face.getLocation().top*inHeight);
        int box_right = (int)(face.getLocation().right*inWidth);
        int box_bottom = (int)(face.getLocation().bottom*inHeight);

        int ret = native_get_align_face(mRockXFaceLandmark5Module, inData, inWidth, inHeight, inPixelFmt,
                box_left, box_top, box_right, box_bottom,
                landmark, alignedFaceData);
        if (ret < 0) {
            return ret;
        }

        face.setLandmark(landmark);
        face.setAlignedFaceData(alignedFaceData);

        return 0;
    }


    public int face_attribute(byte[] inData, GA result) {
        int gaResult[] = new int[2];
        int ret = native_face_attribute(mRockXFaceAnalyzeModule, inData, gaResult);
        result.age = gaResult[1];
        result.gender = gaResult[0];
        if (ret < 0) {
            return ret;
        }
        return 0;
    }


    private native long native_create_rockx_module(String modelPath, int module);
    private native void native_destroy_rockx_module(long handle);
    private native int native_face_detect(long det_handle, long track_handle, byte[] inData,
                                          int inWidth, int inHeight, int max_track_time,
                                          int inPixelFmt, ArrayList<Face> faceList);
    private native int native_get_align_face(long handle, byte[] inData, int inWidth, int inHeight, int inPixelFmt,
                                             int boxLeft, int boxTop, int boxRight, int boxBottom,
                                             int[] outLandmark, byte[] outAlignedFaceData);
    private native int native_face_attribute(long handle, byte[] inData, int[] result);

    static {
        System.loadLibrary("rknn4j");
    }
}
