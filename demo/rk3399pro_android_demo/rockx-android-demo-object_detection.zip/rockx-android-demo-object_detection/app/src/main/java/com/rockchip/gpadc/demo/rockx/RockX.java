package com.rockchip.gpadc.demo.rockx;

import com.rockchip.gpadc.demo.DetectObject;

import java.util.ArrayList;

public class RockX {
    private static final int ROCKX_MODULE_FACE_DETECTION = 1;
    private static final int ROCKX_MODULE_FACE_LANDMARK = 2;
    private static final int ROCKX_MODULE_FACE_RECOGNIZE = 3;
    private static final int ROCKX_MODULE_FACE_ANALYZE = 4;
    private static final int ROCKX_MODULE_OBJECT_DETECTION = 5;
    private static final int ROCKX_MODULE_POSE_BODY = 6;
    private static final int ROCKX_MODULE_POSE_FINGER = 7;
    private static final int ROCKX_MODULE_FACE_5LANDMARKS = 8;
    private static final int ROCKX_MODULE_HEAD_DETECTION = 9;
    private static final int ROCKX_MODULE_CARPLATE_DETECTION = 10;
    private static final int ROCKX_MODULE_CARPLATE_ALIGN = 11;
    private static final int ROCKX_MODULE_CARPLATE_RECOG = 12;
    private static final int ROCKX_MODULE_OBJECT_TRACK = 13;
    private static final int ROCKX_MODULE_FACE_ANTISPOOF = 14;

    public static final int ROCKX_PIXEL_FORMAT_GRAY8 = 0;
    public static final int ROCKX_PIXEL_FORMAT_RGB888 = 1;
    public static final int ROCKX_PIXEL_FORMAT_BGR888 = 2;

    private String mModelPath;

    private long mRockXFaceDetectionModule;
    private long mRockXFaceLandmark5Module;
    private long mRockXFaceRecognitionModule;
    private long mRockXHeadDetectionModule;
    private long mRockxObecjtDetectionModule;

    public RockX(String model_path) {
        mModelPath = model_path;
    }

    public void create() {
        mRockxObecjtDetectionModule = native_create_rockx_module(mModelPath, ROCKX_MODULE_OBJECT_DETECTION);
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        native_destroy_rockx_module(mRockxObecjtDetectionModule);
    }

    public ArrayList<DetectObject> detectObject(byte[] inData, int inWidth, int inHeight, int inPixelFmt) {
        ArrayList<DetectObject> faceList = new ArrayList<>();
        native_detect(mRockxObecjtDetectionModule, inData, inWidth, inHeight, inPixelFmt, faceList);
        return faceList;
    }


    private native long native_create_rockx_module(String modelPath, int module);
    private native void native_destroy_rockx_module(long handle);
    private native int native_detect(long handle, byte[] inData, int inWidth, int inHeight, int inPixelFmt, ArrayList<DetectObject> faceList);


    static {
        System.loadLibrary("rknn4j");
    }
}
