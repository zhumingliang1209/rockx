package com.rockchip.gpadc.demo;

import android.graphics.Rect;
import android.graphics.RectF;

import java.io.Serializable;

public class DetectObject implements Serializable {

    private String name = null;

    private long dbId = -1;

    private int trackId = 0;

    private int cls;

    private Float confidence;

    private RectF location;

    private Rect box;

    private int landmark[] = null;

    public DetectObject() { }

    public DetectObject(String name) {
        this.name = name;
    }

    public DetectObject(String name, long dbIndex) {
        this.name = name;
        this.dbId = dbIndex;
    }

    public DetectObject(int cls, float confidence, RectF location) {
        this.cls = cls;
        this.confidence = confidence;
        this.location = location;
    }

    public DetectObject(float box_left, float box_top, float box_right, float box_bottom, float score) {
        this.cls = 1;
        this.confidence = score;
        this.location = new RectF(box_left, box_top, box_right, box_bottom);
    }

    public DetectObject(float box_left, float box_top, float box_right, float box_bottom, float score, float cls_idx) {
        this.cls = (int)cls_idx;
        this.confidence = score;
        this.location = new RectF(box_left, box_top, box_right, box_bottom);
    }

    public DetectObject(int box_left, int box_top, int box_right, int box_bottom, float score) {
        this.cls = 1;
        this.confidence = score;
        this.box = new Rect(box_left, box_top, box_right, box_bottom);
    }

    public int getCls() {
        return cls;
    }

    public Float getConfidence() {
        return confidence;
    }

    public RectF getLocation() {
        return new RectF(location);
    }

    public void setLocation(RectF location) {
        this.location = location;
    }

    public Rect getBox() {
        return new Rect(this.box);
    }

    public void setTrackId(int trackId) {
        this.trackId = trackId;
    }

    public int getTrackId() {
        return this.trackId;
    }

    @Override
    public String toString() {
        String resultString = "";

        resultString += "[" + cls + "] ";

        if (confidence != null) {
            resultString += String.format("(%.1f%%) ", confidence * 100.0f);
        }

        if (location != null) {
            resultString += location + " ";
        }

        return resultString.trim();
    }

}
